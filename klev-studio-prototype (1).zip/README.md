# Klev-Tech Studio prototype

A standalone, responsive browser prototype for the requested document and video workflow. It is deliberately separate from the public Klev-Tech portfolio: the current deployed page and the workspace `index.html` are different versions, so this prototype does not overwrite either one.

## What works in this prototype

### Documents

- Rich-text editing with headings, paragraphs, bold, italic, underline, quotes, and lists.
- Local document library with search and browser-local autosave.
- Import `.txt`, `.md`, and `.html` text files.
- Starter drafts for project briefs, proposals, meeting notes, emails, blog posts, reports, SOPs, video scripts, presentation outlines, and research summaries.
- Export to `.txt`, `.md`, formatted `.html`, or print / Save as PDF through the browser.

The starter drafts are local templates, **not AI-generated content**. They include placeholders and should be reviewed. Drafts remain in the current browser's `localStorage`; clearing browser data removes them.

### Text-to-video planning

- Accepts prompts, scripts, articles, product briefs, lessons, and social text.
- Creates a scene-by-scene storyboard and a model-ready prompt pack with style, duration, ratio, and avoid-direction fields.
- Saves storyboards locally and exports the prompt pack as Markdown.

This builds a video brief only. It **does not render a video** until an AI video provider and server-side job handling are integrated.

### Live video look preview

- Opt-in local camera preview with browser-side color presets, brightness, contrast, saturation, mirroring, lower-third text, and caption overlays.
- Exports a still preview frame as PNG and saves look presets in the current browser.

This is **not a video call**. There is no remote participant, call-room signaling, live stream, cloud recording, AI background replacement, or remote video effect. A real call editor needs a WebRTC platform and a server integration.

### Files / Assets

- Adds a dedicated Files / Assets navigation view with filters for travel, receipts, and identity samples.
- Includes seven unique, privacy-redacted preview copies of the supplied images. One identical passport-style upload was deduplicated.
- The original uploaded images are not copied into the prototype ZIP. Travel identifiers and itinerary details, transaction values/account details, passport biodata/MRZ, and faces/document photos are covered in the previews.
- The gallery labels document/receipt images as user-supplied and unverified. Receipt images are explicitly marked as not proof of payment; passport-style images are not proof of identity.

## Run locally

From the workspace root:

```bash
python3 -m http.server 8001 --directory klev-studio
```

Open `http://localhost:8001`. Camera access generally requires HTTPS or `localhost`, and the browser will ask permission. The prototype does not request microphone access.

## Production integration required

Do not put model or video-provider API keys in this HTML file or browser storage. A production version needs authenticated server endpoints and secure secret storage. A reasonable implementation plan is:

1. Add accounts, access control, a privacy notice, consent flows, and document/media retention controls.
2. Add a server-side language-model endpoint for document creation and editing. Keep API credentials on the server and let users review generated output.
3. Add one video-generation provider behind an adapter, plus background job queues, progress/error states, quotas, and private media storage. Add more providers after the first path is reliable.
4. Add a WebRTC provider/SFU for real-time rooms, then integrate captions, effects/overlays, recording, and exports. Test camera/microphone permissions and bandwidth on mobile.
5. Add security, accessibility, and cost controls: per-user limits, upload-size limits, deletion controls, consent before recording, encryption, and provider/content-retention disclosures.

The currently deployed `https://klevtech.pages.dev/` portfolio has not been changed by this prototype. To merge it into the deployed product, first provide the source repository or current source export; then deploy through the existing Cloudflare Pages project using an authorized dashboard workflow. Never share passwords or API tokens in chat.
